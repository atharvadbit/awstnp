<?php 
include 'conn.php';

// $servername = "database1.c6rk6zvod6ql.us-east-2.rds.amazonaws.com";
// $username = "admin";
// $password = "password123";
// $dbname = "db1";

// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);
// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }



// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "demo_aws";

// // Create connection
// $conn = new mysqli($servername, $username, $password, $dbname);
// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

if(isset($_POST["submit"]))
{
	
	// $email       =  $_POST['email'];
	// $password  =  $_POST['password'];
	// $pwsd = md5($password);	
	// echo $pwsd;
	// $sql = "SELECT * FROM student_info WHERE email = '$email' and password = '$pwsd'";
 //    $result = mysqli_query($conn,$sql);
 //    $count = mysqli_num_rows($result);
	// if($count==1)
	// {
	// echo " <script>  alert('Successfull Login');
	// window.location.href = 'Home.php';
	// </script> ";
	// // header("location: ./Home.php");
	// }
	// else
	// {
	// echo " <script>  alert('Failed Login');</script> ";
	// header("location: ./AlreadyExist.php");
	// }


	// $email = $_POST['email'];
	// $presql = "SELECT * from student_info WHERE email='$email' ";
	// $result = $conn->query($presql);
	// if ($result->num_rows == 0) {
	// 	echo "Not EXISTS";
	// }
	// else{
	// 	echo " EXISTS";
	// }

	// $fullname = $_POST['full-name'];
	// $email = $_POST['email-address'];
	// $password = $_POST['password1'];
	// $company_name = $_POST['company-name'];
	// $company_address = $_POST['permanent-address'];

	// $sql = "INSERT into hr_job (hrname,hremail,hrpassword,hrcompany,address) values ('$fullname', '$email', '$password', '$company_name','$company_address')";
	// if($conn->query($sql) === TRUE){
	// 	echo "<script> alert('HR Registered Successfully')</script>";
	// }
	// else{
	// 	echo "<script> alert('HR Registration Failed')</script>";	
	// }


	// $sql = "INSERT into demo (id,name) values ('2','ASD')";
	// if($conn->query($sql) === TRUE){
	// 	echo "<script> alert(' Successfully')</script>";
	// }
	// else{
	// 	echo "<script> alert('Failed')</script>";	
	// }


	session_start();
	$id =$_POST['id'];
    $query = "SELECT studentid, email, fullname, mobile, gender from student_info WHERE studentid='$id' ";
    $result = mysqli_query($conn,$query);
	
	$row = mysqli_fetch_array($result);
    $_SESSION['id'] = $row[0];
    $_SESSION['email'] = $row[1];
    $_SESSION['fullname'] = $row[2];

}


?>

<html>
<body>

<form action="success.php" method="post">
	<input type="text" name="id" >
	<input type="submit" name="submit">
	
</form>

</body>
</html>