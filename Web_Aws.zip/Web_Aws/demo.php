<?php  
if (isset($_POST['submit'])) {
  # code...


  echo "
  <script>
  alert('Submited sucessfully');
  </script>
  ";
}

?>

<!DOCTYPE html>
<html>
<head>
    <title></title>

<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<style type="text/css">
    .help-block{
    color:#b94a48;
    }
</style>
</head>
<body>
  <script type="text/javascript">
    function submit() {
      alert("Submited");
    }
  </script>

  <form action="" method="post">
    <input type="submit" name="submit">
    <a href="#" onclick="submit();"> submit</a>
  </form>
</body>
</html>