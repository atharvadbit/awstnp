<?php 



if (isset($_POST['submit'])) {
  # code...
  echo "
  <script>
  alert('Submited sucessfully');
  </script>
  ";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      padding-top: 20px;
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
    }
    #id1{
      height: 400px;
      border-style: solid; 
    }
    #id2{
      /*height: 600px;*/
      border-style: dotted;
      border-radius: 20px;
      margin: 20px;
      padding: 20px;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Projects</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
  
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-3" id="id1">
      Helo
    </div>
    <div class="col-lg-8" id="id2">
<form method="post" action="">
        <table class="table" >
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Ques</th>
            <th scope="col">Answer</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Current Sem</td>
            <td>
              <select name="CurrentSem">
                <option value="-1" selected>
                  [choose yours]
                </option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
              </select>
            </td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>SSC</td>
            <td><input type="text" name=""></td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>HSC/Diploma</td>
            <td><input type="text" name=""></td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td>Semester 1</td>
            <td><input type="text" name="sem1" required=""></td>
          </tr>
          <tr>
            <th scope="row">5</th>
            <td>Semester 2</td>
            <td><input type="text" name="sem2" required=""></td>
          </tr>
          <tr>
            <th scope="row">6</th>
            <td>Semester 3</td>
            <td><input type="text" name="sem3" required=""></td>
          </tr>
          <tr>
            <th scope="row">7</th>
            <td>Semester 4</td>
            <td><input type="text" name="sem4" required=""></td>
          </tr>
          <tr>
            <th scope="row">8</th>
            <td>Semester 5</td>
            <td><input type="text" name="sem5" required=""></td>
          </tr>
          <tr>
            <th scope="row">9</th>
            <td>Semester 6</td>
            <td><input type="text" id="sem6" name="sem6" required=""></td>
          </tr>
          <tr>
            <th scope="row">10</th>
            <td>Semester 7</td>
            <td><input type="text" id="sem7" name="sem7" required=""></td>
          </tr>
          <tr>
            <th scope="row">11</th>
            <td>Semester 8</td>
            <td><input type="text" id="sem8" name="sem8" required=""></td>
          </tr>
          <tr>
            <th scope="row">12</th>
            <td>Percentage</td>
            <td><input type="text" name="" ></td>
          </tr>
          <tr>
            <td colspan="3"><input type="submit" name="submit" value="Submit" align="center"></td>
          </tr>
          </tbody>
        </table>

        
          
</form>

        
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>

<script type="text/javascript">
  var cursemelement = document.getElementsByName('CurrentSem')[0]

  cursemelement.onblur = function () {
    // body...
    var cursem = cursemelement.options[cursemelement.selectedIndex].value ;//document.CurrentSem.value;


    if (cursem==6) {
      document.getElementById("sem7").disabled = true;
      document.getElementById("sem8").disabled = true;
      document.getElementById("sem7").value = 0
      document.getElementById("sem8").value = 0
    } else if (cursem==7) {
      document.getElementById("sem7").disabled = false;
      document.getElementById("sem8").disabled = true;
      document.getElementById("sem8").value = 0
    }
    else if(cursem ==8)
    {
      document.getElementById("sem7").disabled = false;
      document.getElementById("sem8").disabled = false;
      document.getElementById("sem8").value = "";
      document.getElementById("sem7").value = ""; 
    }
  }
</script>
</body>
</html>
