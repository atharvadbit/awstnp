<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aws";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['register'])) {
	# code...
	$email = $_POST['Email'];
	$password = $_POST['Password1'];
	$fullname = $_POST['FullName'];
	$mobile = $_POST['Mobile'];
	$city = $_POST['City'];
	$gender = $_POST['gender'];
	$college = $_POST['College'];
	$branch = $_POST['Branch'];
	$psswd = md5($password);

	$presql = "SELECT * from student_info WHERE email='$email' ";
	$result = $conn->query($presql);
	if ($result->num_rows == 0) {
		$sql = "INSERT INTO student_info (email,password,fullname,mobile,gender,hometown,clg,branch)
		VALUES (  '$email','$psswd','$fullname','$mobile','$gender','$city','$college','$branch')";

		if ($conn->query($sql) === TRUE) {
		  		echo '<script language="javascript">';
				echo 'alert("Successfully Regis")';
				echo '</script>';
		  		header("location: ./User_Login.php");
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}		
	}
	else{
		echo "
		<script>
		alert('Already User Email Exists')
		</script>
		";
	}
	

}


$conn->close();




?>

<!DOCTYPE html>
<html>
<head>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title>Form Validation</title>
</head>
<body>

<!-- <form name="myform" onsubmit="return(validate());">
	<table cellpadding="2" cellspacing="2" border="1">

		<tr>
			<td align="right">Email</td>
			<td><input type="text" name="Email"></td>
		</tr>
		
		<tr>
			<td align="right">Password</td>
			<td><input type="password" name="Password1"></td>
		</tr>
		
		<tr>
			<td align="right">Confirm Password</td>
			<td><input type="password" name="Password2"><span id='error'></span></td>
			
		</tr>

		<tr>
			<td align="right">Full Name</td>
			<td><input type="text" name="FullName"></td>
		</tr>

		<tr>
			<td align="right">Mobile</td>
			<td><input type="text" name="Mobile"></td>
		</tr>

		<tr>
			<td align="right">Gender</td>
			<td>
				<input type="radio" id="male" name="gender" value="male"><label for="male">Male</label> 
				<input type="radio" id="female" name="gender" value="female"><label for="female">Female</label><br>
			</td>
		</tr>

		<tr>
			<td align="right">Residance City</td>
			<td><input type="text" name="City"></td>
		</tr>



		<tr>
			<td align="right">College</td>
			<td>
				<select name="College">
					<option value="-1" selected>
						[choose yours]
					</option>
					<option value="DBIY">DBIT</option>
					<option value="VIT">VIT</option>
					<option value="VJTI">VJTI</option>
				</select>
			</td>
		</tr>

		<tr>
			<td align="right">Branch</td>
			<td>
				<select name="Branch">
					<option value="-1" selected>
						[choose yours]
					</option>
					<option value="COMPS">COMPS</option>
					<option value="IT">IT</option>
					<option value="MECH">MECH</option>
				</select>
			</td>
		</tr>



		<tr>
			<td align="right"></td>
			<td><input type="submit" name="Submit"></td>
		</tr>
	</table>


</form> -->

<main class="my-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Register</div>
                        <div class="card-body">
                            <form name="myform" onsubmit="return validate()" action="User_Reg.php" method="post">
                                <div class="form-group row">
                                    <label for="Email" class="col-md-4 col-form-label text-md-right">Email</label>
                                    <div class="col-md-6">
                                        <input type="text" id="" class="form-control" name="Email">
                                        <span id='errorEmail'></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Password1" class="col-md-4 col-form-label text-md-right">Password</label>
                                    <div class="col-md-6">
                                        <input type="password" id="" class="form-control" name="Password1">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Password2" class="col-md-4 col-form-label text-md-right">Confirm Password</label>
                                    <div class="col-md-6">
                                        <input type="password" id="" class="form-control" name="Password2"><span id='error'></span>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Full Name" class="col-md-4 col-form-label text-md-right">Full Name</label>
                                    <div class="col-md-6">
                                        <input type="text" id="" class="form-control" name="FullName">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Mobile" class="col-md-4 col-form-label text-md-right">Mobile</label>
                                    <div class="col-md-6">
                                        <input type="text" id="" class="form-control" name="Mobile">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Residance_City" class="col-md-4 col-form-label text-md-right">Residance City</label>
                                    <div class="col-md-6">
                                        <input type="text" id="" class="form-control" name="City">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Gender" class="col-md-4 col-form-label text-md-right">Gender</label>
                                    <div class="col-md-6">
                                        <input type="radio" id="male" name="gender" value="male"><label for="male">Male</label> 
										<input type="radio" id="female" name="gender" value="female"><label for="female">Female</label>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="College" class="col-md-4 col-form-label text-md-right">College</label>
                                    <div class="col-md-6">
													<select name="College">
																		<option value="-1" selected>
																			[choose yours]
																		</option>
																		<option value="DBIY">DBIT</option>
																		<option value="VIT">VIT</option>
																		<option value="VJTI">VJTI</option>
																	</select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="Stream" class="col-md-4 col-form-label text-md-right">Stream</label>
                                    <div class="col-md-6">
                                        <select name="Branch">
											<option value="-1" selected>
												[choose yours]
											</option>
											<option value="COMPS">COMPS</option>
											<option value="IT">IT</option>
											<option value="MECH">MECH</option>
										</select>
									</div>
                                </div>                                

                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary" name="register">
                                        Register
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
        </div>
    </div>

</main>


<script type="text/javascript">
	
 	var email1 = document.getElementsByName('Email')[0]
 	var ErrEmail = document.getElementById('errorEmail')

 	email1.onblur = function (){

 		if(validateEmail()==true){
 			ErrEmail.innerHTML = 'Valid Email'
 			return(true)
 		}
 		else{
 			ErrEmail.innerHTML = 'InValid Email'	
 			return(false)
 		}
 	}

 	email1.onfocus = function (){
 	this.style.backgroundColor = ''
	ErrEmail.innerHTML = ''	
 	}

	var pass1 = document.getElementsByName('Password1')[0]
	var pass2 = document.getElementsByName('Password2')[0]
	var errorHolder = document.getElementById('error')

	pass2.onfocus = function () {
	this.style.backgroundColor = ''
	errorHolder.innerHTML = ''
	} 


	pass2.onblur = function(){
	var pass3 = +this.value 
	var pass4 = document.myform.Password1.value;
	var pass5 = document.myform.Password2.value;
	
		if (pass4 == ''){ 
			this.style.backgroundColor = 'red'
			errorHolder.innerHTML = 'Enter a Password please.'
			alert("Please Enter Password!")
		    return (false)
		}else if (pass5 == '') {
			this.style.backgroundColor = 'red'
			errorHolder.innerHTML = 'Enter a Password please.'
			alert("Please Enter Password")
		    return (false)
		}
		else if (pass4 != pass5) { 
                    this.style.backgroundColor = 'red'
                    errorHolder.innerHTML ="Password did not match: Please try again..." 
                } 
                // If same return True. 
                else{ 
                    this.style.backgroundColor = 'green'
                    errorHolder.innerHTML ="Password match successfully..." 
                } 
	}


	function validateEmail(){
		// var emailID = document.myform.Email.value;
		// atpos = emailID.indexof("@");
		// dot.pos = emailID.lastIndexOf(".");
		// if(atpos < 1 || (dotpos - atpos < 2 ))
		// {
		// 	alert("Please Enter correct Email ID");
		// 	document.myform.Email.focus();
		// 	return (false);
		// }
		// return(true);
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myform.Email.value))
		  {
		    return (true)
		  }
		    alert("You have entered an invalid email address!")
		    return (false)
	}

	function validate()
	{
		if(document.myform.Email.value == ""){
			alert("Please provide Your Email");
			document.myform.Email.focus();
			return false;
		}
		validateEmail();

		if (document.myform.FullName.value == "") {
			alert("Please provide your name!");
			document.myform.FullName.focus();
			return false;
		}
		if (document.myform.Mobile.value == "" || isNaN(document.myform.Mobile.value) ||document.myform.Mobile.value.length != 10) {
			alert("Please provide a Mobile in the format");
			document.myform.Mobile.focus();
			return false;
		}
		if (document.myform.City.value =="") {
			alert("Please provide Your City");
			return false;
		}
		if (document.myform.College.value =="-1") {
			alert("Please provide Your College");
			return false;
		}
		if (document.myform.Branch.value =="-1") {
			alert("Please provide Your Branch");
			return false;
		}

		return(true);
	}
</script>
</body>
</html>