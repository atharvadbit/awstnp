<?php
if (isset($_POST['submit'])) {
  # code...
  $currentsem = $_POST['CurrentSem'];

  $sem1 = $_POST['sem1'];
  $sem2 = $_POST['sem2'];
  $sem3 = $_POST['sem3'];
  $sem4 = $_POST['sem4'];
  $sem5 = $_POST['sem5'];
  $sem6 = $_POST['sem6'];
  if ($currentsem == 6) {
   $sem7 = 0;
   $sem8 = 0;
  }
  elseif ($currentsem == 7) {
   $sem7 = $_POST['sem7'];
   $sem8 = 0;
  }
  else
  {
   $sem7 = $_POST['sem7'];
   $sem8 = $_POST['sem8'];
  }
  $percentage = $_POST['percentage'];

  echo "Percentage ",$percentage;


}

?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form id="form1" method="POST">
  
        <table class="table" >
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Ques</th>
            <th scope="col">Answer</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Current Sem</td>
            <td>
              <select name="CurrentSem">
                <option value="-1" selected>
                  [choose yours]
                </option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
              </select>
            </td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td>Semester 1</td>
            <td><input type="text" id="sem1" maxlength="3" name="sem1" required="" value=" <?php echo $row1[2]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">5</th>
            <td>Semester 2</td>
            <td><input type="text" id="sem2" maxlength="3" name="sem2" required="" value=" <?php echo $row1[3]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">6</th>
            <td>Semester 3</td>
            <td><input type="text" id="sem3" maxlength="3" name="sem3" required="" value=" <?php echo $row1[4]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">7</th>
            <td>Semester 4</td>
            <td><input type="text" id="sem4" maxlength="3" name="sem4" required="" value=" <?php echo $row1[5]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">8</th>
            <td>Semester 5</td>
            <td><input type="text" id="sem5" maxlength="3" name="sem5" required="" value=" <?php echo $row1[6]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">9</th>
            <td>Semester 6</td>
            <td><input type="text" id="sem6" maxlength="3" name="sem6" required="" value=" <?php echo $row1[7]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">10</th>
            <td>Semester 7</td>
            <td><input type="text" id="sem7" maxlength="3" name="sem7" required="" value=" <?php echo $row1[8]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">11</th>
            <td>Semester 8</td>
            <td><input type="text" id="sem8" maxlength="3" name="sem8" required="" value=" <?php echo $row1[9]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">12</th>
            <td>Percentage</td>
            <td><input type="text" id="percentage" name="percentage" readonly="">    </td>
          </tr>
          <tr>
            <td colspan="3"><button type="button" class="btn btn-dark" onclick="submit1()">Calculte</button> 
              <input type="submit" name="submit" class="btn btn-success" id="myBtn" value="Submit" disabled> 
            </td>
          </tr>
          </tbody>
        </table>
</form>




<script type="text/javascript">
  // #form1 select, #form1 input, 
  $('#form input').blur(function(){
    $(this).css('background-color', 'black');
});

  function submit1() {
    document.getElementById("myBtn").disabled = false;



     var sem1 = document.getElementById("sem1").value;
     var sem2 = document.getElementById("sem2").value;
     var sem3 = document.getElementById("sem3").value;
     var sem4 = document.getElementById("sem4").value;
     var sem5 = document.getElementById("sem5").value;
     var sem6 = document.getElementById("sem6").value;
     var sem7 = document.getElementById("sem7").value;
     var sem8 = document.getElementById("sem8").value;
    
     var num1 = parseInt(sem1)
     var num2 = parseInt(sem2)
     var num3 = parseInt(sem3)
     var num4 = parseInt(sem4)
     var num5 = parseInt(sem5)
     var num6 = parseInt(sem6)
     var num7 = parseInt(sem7)
     var num8 = parseInt(sem8)
     
    var cursemelement = document.getElementsByName('CurrentSem')[0]
     var cursem = cursemelement.options[cursemelement.selectedIndex].value
     var num = parseInt(cursem)

    // document.write("Sum Sem1 : "+sem1)
    // document.write("<br>Sum Sem2 : "+sem2)
    // document.write("<br>Sum Sem3 : "+sem3)
    // document.write("<br>Sum Sem4 : "+sem4)
    // document.write("<br>Sum Se5 : "+sem5)
    // document.write("<br>Sum Sem6 : "+sem6)
    // document.write("<br>Sum Sem7 : "+sem7)
    // document.write("<br>Sum Sem8 : "+sem8)
    // document.write("<br>cur Sem : "+cursem)

     var sumsem = parseFloat(num1 + num2 + num3+ num4+ num5+ num6+ num7+ num8);
    // document.write("<br>Sum Sem : "+sumsem)
     var avgsumsem = parseFloat(sumsem/num);
    // document.write("<br>Avg Sem : "+avgsumsem)
     var percent = parseFloat(7.1 * avgsumsem + 12) ;
    // document.write("percent : "+percent)
    
    document.getElementById("percentage").value = percent;
        document.getElementById("percentage1").value = percent;
  }

</script>
</body>
</html>


