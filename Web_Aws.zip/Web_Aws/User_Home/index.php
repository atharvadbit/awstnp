<?php

session_start();

include 'conn.php';
          // echo $_SESSION['email'],"<br>";
          // echo $_SESSION['fullname'],"<br>";
          // echo $_SESSION['id'],"<br>";
          // echo $_SESSION['mobile'],"<br>" ;
          // echo $_SESSION['gender'],"<br>" ;
          
$id = $_SESSION['id'];




$sqljobview = "SELECT u.regid, u.jobid, u.hrid, j.ctc, j.designation, h.hrname, h.hrcompany, u.status, u.round 
                from user_job_reg u INNER JOIN hr_job h on h.hrid = u.hrid INNER JOIN job j on j.jobid = u.jobid
                where u.studentid = '$id' ";

$resjobview=$conn->query($sqljobview);
// {
//   // echo "<script> alert('Successfull') </script>";

//   $regid = $rowjobview[0];
//   $jobid = $rowjobview[1];
//   $hrid = $rowjobview[2];
//   $ctc = $rowjobview[3];
//   $designation = $rowjobview[4];
//   $hrname = $rowjobview[5];
//   $hrcompany = $rowjobview[6];
//   $status = $rowjobview[7];  
//   $round = $rowjobview[8];

//   echo $regid,"<br>";
//   echo $jobid,"<br>";
//   echo $hrid,"<br>";
//   echo $ctc,"<br>";
//   echo $designation,"<br>";
//   echo $hrname,"<br>";
//   echo $hrcompany,"<br>";
//   echo $status,"<br>";
//   echo $round,"<br>";
// }
// else
// {
//  echo "<script> alert('Fail') </script>"; 
// }



?>
<!DOCTYPE html>
<html lang="en">

<head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>User Home</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style type="text/css">
  #id1{
    display: block;
  }
  #id2{
    display: none;
  }
  #id3{
    display: none;
  }
  #id4{
    display: none;
  }
</style>
</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Welcome to T&P </div>
      <div class="list-group list-group-flush">
        <button type="button" class="btn btn-outline-dark" onclick="myFunction1()">Dashboard</button>
        <button type="button" class="btn btn-outline-dark" onclick="myFunction2()">Events</button>
        <button type="button" class="btn btn-outline-dark" onclick="myFunction3()">Profile</button>
        <button type="button" class="btn btn-outline-dark" onclick="myFunction4()">Status</button>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Student Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Apply Now <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="User_Details.php">User Details</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logout.php">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <div id="id1">

          <?php 
            $sql = "SELECT * from student_info where studentid= '$id' ";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($result);



          ?>
          
          <h3>User Information Dashboard</h3>
          <hr size="10" noshade>
          <center>
          <table class="table table-hover table-fixed" style="width: 50%;">
            <tr>
              <td>User Full Name :</td>
              <td><?php echo $row[3]; ?></td>
            </tr>

            <tr>
              <td>User ID :</td>
              <td><?php echo $row[0]; ?></td>
            </tr>

            <tr>
              <td>User Email ID :</td>
              <td><?php echo $row[1]; ?></td>
            </tr>

            <tr>
              <td>Mobile No :</td>
              <td> <?php echo $row[4]; ?></td>
            </tr>

            <tr>
              <td>Gender :</td>
              <td> <?php echo $row[5]; ?></td>
            </tr>

            <tr>
              <td>HownTown :</td>
              <td><?php echo $row[6]; ?></td>
            </tr>

            <tr>
              <td>College :</td>
              <td><?php echo $row[7]; ?> </td>
            </tr>

            <tr>
              <td>Branch : </td>
              <td><?php echo $row[8]; ?></td>
            </tr>

            <tr>
              <td>Marks Entry</td>
              <td> <?php 
                  if ($row[12] == 0) {
                    echo "Update your Marks   <a href='User_Details.php'>Click Here to update</a>";
                  }
                  else
                  {
                    echo "Marks are updated";
                  }



                ?> </td>
            </tr>

          </table>
          </center>
          <hr size="10" noshade>
        </div>
        <div id="id2">
                    <center>
                      <h3>Drive Upcoming</h3>
          <table class="table table-hover table-stripped table-fixed" style="width: 85%">
            <tr>
              <th>Job ID</th>
              <th>CTC</th>
              <th>Stream</th>
              <th>Location</th>
              <th>Designation</th>
              <th>SSC</th>
              <th>HSC</th>
              <th>BE</th>
              <th>Date</th>
              <th>No of Rounds</th>
              <th>View Info</th>
            </tr>

            <?php
              $jobsql = "SELECT `jobid`, `ctc`, `stream`, `location`, `designation`, `ssc`, `hsc`, `be_criteria`, `date`, `round` FROM `job` where status=1 ";
              #$resultjob = $conn->query($jobsql);
              if ($result = $conn->query($jobsql)) {
                  // output data of each row
                  while($rowjob = $result->fetch_assoc()) { ?>
                      <tr>
                          <td><?php echo $rowjob['jobid'] ?>  </td>
                          <td><?php echo $rowjob['ctc'] ?> </td>
                          <td><?php echo $rowjob['stream'] ?></td>
                          <td><?php echo $rowjob['location'] ?></td>
                          <td><?php echo $rowjob['designation'] ?></td>
                          <td><?php echo $rowjob['ssc'] ?></td>
                          <td><?php echo $rowjob['hsc'] ?></td>
                          <td><?php echo $rowjob['be_criteria'] ?></td>
                          <td><?php echo $rowjob['date'] ?></td>
                          <td><?php echo $rowjob['round'] ?></td>
                          <td> <a href="user_reg_job.php?jobid= <?php echo  base64_encode($rowjob['jobid']);?>" target="_blank"> View Details</a></td>
                       </tr> 
                 <?php }
              } 


            ?>
            
          </table>
          </center>
        </div>
        <div id="id3">
         <h3>User Profile Semester Marks</h3> 

        <hr>
        <hr>
        <center>
          
          <table class="table table-striped table-hover table-fixed" style="width: 50%;">
            <thead>
              <tr>
                <th scope="col">Sr. No</th>
                <th scope="col">Info</th>
                <th scope="col">Details</th>

              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">3</th>
                <th>Current Sem</th>
                <td><?php  echo $row[9];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>SSC</th>
                <td><?php echo $row[10];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>HSC/Diploma</th>
                <td><?php echo $row[11];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 1</th>
                <td><?php echo $row[13];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 2</th>
                <td><?php echo $row[14];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 3</th>
                <td><?php echo $row[15];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 4</th>
                <td><?php echo $row[16];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 5</th>
                <td><?php echo $row[17];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 6</th>
                <td><?php echo $row[18];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 7</th>
                <td><?php echo $row[19];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Semester 8</th>
                <td><?php echo $row[20];  ?></td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <th>Percentage</th>
                <td><?php echo $row[21];  ?></td>
              </tr>
            </tbody>
          </table>
          <p><b>Note:</b> To Update Marks Click on EDIT MARKS on Navigation Bar.</p>
        </center>
        <hr>
        <hr>
          </div>
        <div id="id4">
          <br>
          <h4>Jobs Applied For</h4>
          <hr>
          <hr>
          <table class="table table-striped table-hover table-fixed" width="70%">
            <thead class="thead-dark">
              <tr>
                <th> Register ID</th>
                <th> Job ID</th>
                <th> CTC</th>
                <th>Designation</th>
                <th>Hrname</th>
                <th>Company</th>
                <th>Status</th>
                <th>Round</th>
              </tr>
            </thead>
           <?php
           while( $rowjobview = mysqli_fetch_array($resjobview)){
              $regid = $rowjobview[0];
              $jobid = $rowjobview[1];
              $hrid = $rowjobview[2];
              $ctc = $rowjobview[3];
              $designation = $rowjobview[4];
              $hrname = $rowjobview[5];
              $hrcompany = $rowjobview[6];
              $status = $rowjobview[7];  
              $round = $rowjobview[8];
           ?> 
            <tr>
              <td> <?php echo $regid; ?></td>
              <td> <?php echo $jobid; ?></td>
              <td> <?php echo $ctc; ?></td>
              <td> <?php echo $designation; ?></td>
              <td> <?php echo $hrname; ?></td>
              <td> <?php echo $hrcompany; ?></td>
              <td> <?php echo $status; ?></td>
              <td> <?php echo $round; ?></td>
            </tr>
         <?php  } ?>
          </table>
          <hr>
          <hr>






        </div>
      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>


<script type="text/javascript">
  
  function myFunction1() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");  
  if (x.style.display === "none") {
    x.style.display = "block";
  } 
  else{
    x.style.display="none";
    y.style.display = "none";
    z.style.display ="none";
    a.style.display = "none";
  }
}
  
  function myFunction2() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (y.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
    a.style.display="none";
  } else {
    y.style.display = "block";
    x.style.display="none";
    z.style.display = "none";
    a.style.display="none";
  }
}

function myFunction3() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (z.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
        a.style.display="none";

  } else {
    z.style.display = "block";
    x.style.display="none";
    y.style.display = "none";
        a.style.display="none";

  }
}

function myFunction4() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (a.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
    a.style.display = "none";
  } else {
    a.style.display = "block";
    x.style.display="none";
    z.style.display = "none";
    y.style.display="none";
  }
}

</script>
</body>

</html>
