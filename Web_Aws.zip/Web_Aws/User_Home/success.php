<?php 
session_start();
#include 'conn.php';

if(isset($_POST["submit"]))
{
	
	// $email       =  $_POST['email'];
	// $password  =  $_POST['password'];
	// $pwsd = md5($password);	
	// echo $pwsd;
	// $sql = "SELECT * FROM student_info WHERE email = '$email' and password = '$pwsd'";
 //    $result = mysqli_query($conn,$sql);
 //    $count = mysqli_num_rows($result);
	// if($count==1)
	// {
	// echo " <script>  alert('Successfull Login');
	// window.location.href = 'Home.php';
	// </script> ";
	// // header("location: ./Home.php");
	// }
	// else
	// {
	// echo " <script>  alert('Failed Login');</script> ";
	// header("location: ./AlreadyExist.php");
	// }


	// $email = $_POST['email'];
	// $presql = "SELECT * from student_info WHERE email='$email' ";
	// $result = $conn->query($presql);
	// if ($result->num_rows == 0) {
	// 	echo "Not EXISTS";
	// }
	// else{
	// 	echo " EXISTS";
	// }

	// $fullname = $_POST['full-name'];
	// $email = $_POST['email-address'];
	// $password = $_POST['password1'];
	// $company_name = $_POST['company-name'];
	// $company_address = $_POST['permanent-address'];

	// $sql = "INSERT into hr_job (hrname,hremail,hrpassword,hrcompany,address) values ('$fullname', '$email', '$password', '$company_name','$company_address')";
	// if($conn->query($sql) === TRUE){
	// 	echo "<script> alert('HR Registered Successfully')</script>";
	// }
	// else{
	// 	echo "<script> alert('HR Registration Failed')</script>";	
	// }

	// $studid=$_POST['studid'];
	// $currentsem = $_POST['CurrentSem'];
	// $ssc = $_POST['ssc'];
	// $hsc = $_POST['hsc'];
	// $sem1 = $_POST['sem1'];
	// $sem2 = $_POST['sem2'];
	// $sem3 = $_POST['sem3'];
	// $sem4 = $_POST['sem4'];
	// $sem5 = $_POST['sem5'];
	// $sem6 = $_POST['sem6'];
	// if ($currentsem == 6) {
	// 	$sem7 = 0;
	// 	$sem8 = 0;
	// }
	// elseif ($currentsem == 7) {
	// 	$sem7 = $_POST['sem7'];
	// 	$sem8 = 0;
	// }
	// else
	// {
	// 	$sem7 = $_POST['sem7'];
	// 	$sem8 = $_POST['sem8'];
	// }
	// $percentage = $_POST['percentage'];

	// $sql = "UPDATE student_info set currentsem='$currentsem', ssc='$ssc', hsc_diploma='$hsc', sem1='$sem1',sem2='$sem2',sem3='$sem3',sem4='$sem4',sem5='$sem5',sem6='$sem6',sem7='$sem7',sem8='$sem8', percentage='$percentage' where studentid ='$studid' ";
	// if($conn->query($sql) === TRUE){
	// 	echo "<script> alert('Student details UPDATE')</script>";
	// }
	// else{
	// 	echo "<script> alert('Student Updation Failed')</script>";	
	// }

echo "Submit <br>";

echo $_POST['jobid'],"<br>";
echo $_POST['id'],"<br>";
}
else
{
	echo "Not";
}


?>

<html>
<body>

<!-- 	          <?php 


          // echo $_SESSION['email'],"<br>";
          // echo $_SESSION['fullname'],"<br>";
          // echo $_SESSION['id'],"<br>";
          // echo $_SESSION['mobile'],"<br>" ;
          // echo $_SESSION['gender'],"<br>" ;


          ?> -->



</body>
</html>