<?php

session_start();
include 'conn.php';          
$id = $_SESSION['id'];

$sql2 = "SELECT  `ssc`, `hsc_diploma`, `percentage` FROM `student_info` WHERE studentid = '$id' ";
$res = $conn->query($sql2);
$row = mysqli_fetch_array($res);
$ssc = $row[0];
$hsc = $row[1];
$be = $row[2];


if (isset($_GET['jobid'])) {
	$jobid = base64_decode($_GET['jobid']);
	$sql1 = " SELECT j.jobid , j.hrid, j.ctc, j.stream, j.location, j.designation, j.ssc, j.hsc, j.be_criteria, j.date, h.hrname, h.hremail, h.hrcompany, h.address , j.round
	from job j INNER JOIN hr_job h on j.hrid = h.hrid  where j.jobid='$jobid' ";
	if ($result = $conn->query($sql1)) {
		#$rowjob = $result->fetch_assoc();
		$rowjob = mysqli_fetch_array($result);
		$round = $rowjob[14];
	}
	else
	{
		echo "<script> alert('error')</script>";
	}



				$flag1 =0;
				$flag2 =0;
				$flag3 =0;
				$flag = 0;
				$str = " ";
				if($ssc >= $rowjob[6])
					$flag1=1;
				else
					$flag1=0;

				if($hsc >= $rowjob[7])
					$flag2=1;
				else
					$flag2=0;

				if ($be >= $rowjob[8]) {
					$flag3=1;
				}
				else
					$flag3=0;

				if ($flag1 == 1 && $flag2 == 1 && $flag3==1 ) {
					$str = "Your eligble for Registration";
					$flag=1;
				}
				else{
					$str = "Your Not eligble for Registration. Your Criteria is not as per our requried. See you again in next Drive";
					$flag = 0;
					
				}

}





?>
     



<!DOCTYPE html>
<html>
<head>



  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>User Job Register</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <a class="btn btn-primary" id="menu-toggle">Home Page</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Apply Now <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#" >Jobs View</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logout.php">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>
          </ul>
        </div>
</nav>

<div class="container-fluid">
        <div id="id1">
          <center>
          <h3>Job Registration</h3>
          	
            <table class="table table table-secondary table-hover table-stripped table-fixed" style="width: 60%">
				<thead class="thead-dark">
				<tr align="center">
					<th colspan="2">Job Details</th>
				</tr>
				<tr>
				</thead>
					<th>Job ID</th>
					<td><?php echo $rowjob[0] ?>  </td>
			    </tr> 
			    <tr>
			    	<th>CTC</th>
			        <td><?php echo $rowjob[2] ?> </td>
			    </tr> 
			    <tr> 
			    	<th>Stream</th>
			       <td><?php echo $rowjob[3] ?></td>
			    </tr> 
			    <tr>    
			    	<th>Location</th>
			    	<td><?php echo $rowjob[4] ?></td>
			     </tr> 
			     <tr>   
			     	<th>Desgination</th>
			     	<td><?php echo $rowjob[5] ?></td>
			     </tr> 
			     <tr>   
			     	<th> Date </th>
			     	<td><?php echo $rowjob[9] ?></td>
			     </tr> 
			     <tr> 
				     <th>HR Name</th> 
			 	     <td><?php echo $rowjob[10] ?></td>
			     </tr> 
			     <tr>
			     	<th> HR Email </th> 
			       <td><?php echo $rowjob[11] ?></td>
			      </tr>
			       <tr> 
			       	<th>Company Name</th>
			        <td><?php echo $rowjob[12] ?></td>
			      </tr> 
			      <tr> 
			      	<th>Company Address</th>
			       <td><?php echo $rowjob[13] ?></td>
				</tr>
				<tr>
					<th>No of Rounds</th>
					<td><?php echo $round; ?></td>
				</tr>

			</table>
			<table class="table table-fixed table-secondary table-hover table-stripped" style="width: 60%;">
				<thead class="thead-dark">
					<tr align="center">
						<th colspan="3"> Company Criteria</th>
					</tr>	
				</thead>
				<tr align="center">
					<th>Criteria</th>
					<th>Expected Marks</th>
					<th>Actual Marks</th>
				</tr>
				<tr align="center">
					<td>SSC</td>
					<td> <?php echo $rowjob[6]; ?> </td>
					<td> <?php echo $ssc; ?> </td>
				</tr>
				<tr align="center">
					<td>HSC/ Diploma</td>
					<td> <?php echo $rowjob[7]; ?> </td>
					<td> <?php echo $hsc; ?> </td>					
				</tr>
				<tr align="center">
					<td>BE Aggregate</td>
					<td> <?php echo $rowjob[8]; ?> </td>
					<td> <?php echo $be; ?></td>
				</tr>

				<tr align="center">
					<td colspan="3"><b> Remarks: </b> <?php echo $str;  ?> </td>
				</tr>
				<form method="post" action="user_reg_job1.php">
					<input type="hidden" name="jobid" value="<?php echo $jobid ?>">
					<input type="hidden" name="id" value="<?php echo $id ?>">
				<tr align="center">
					<td colspan="3"><input type="submit" class="btn btn-primary" name="submit" id='myBtn'></td>
					<?php
					if ($flag == 0) {
						# code...
						echo "
							<script>
							 document.getElementById('myBtn').disabled = true; </script>
							";
					}
					?>
				</tr>
				</form>
			</table>
          </center>
        </div>
</div>

<script type="text/javascript">

		
</script>
</body>
</html>