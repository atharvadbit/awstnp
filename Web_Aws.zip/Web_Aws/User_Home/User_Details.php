
<?php


include 'conn.php';
session_start();
$id = $_SESSION['id'];

$sql1 = "SELECT `ssc`,`hsc_diploma`,`sem1`,`sem2`,`sem3`,`sem4`,`sem5`,`sem6`,`sem7`,`sem8`,`percentage` FROM `student_info` WHERE studentid= '$id' ";
$result1 = mysqli_query($conn,$sql1);
$row1 = mysqli_fetch_array($result1);


if (isset($_POST['submit'])) {
  # code...
  $currentsem = $_POST['CurrentSem'];
  $ssc = $_POST['ssc'];
  $hsc = $_POST['hsc'];
  $sem1 = $_POST['sem1'];
  $sem2 = $_POST['sem2'];
  $sem3 = $_POST['sem3'];
  $sem4 = $_POST['sem4'];
  $sem5 = $_POST['sem5'];
  $sem6 = $_POST['sem6'];
  if ($currentsem == 6) {
   $sem7 = 0;
   $sem8 = 0;
  }
  elseif ($currentsem == 7) {
   $sem7 = $_POST['sem7'];
   $sem8 = 0;
  }
  else
  {
   $sem7 = $_POST['sem7'];
   $sem8 = $_POST['sem8'];
  }
  $percentage = $_POST['percentage'];

  $sql = "UPDATE student_info set currentsem='$currentsem', ssc='$ssc', hsc_diploma='$hsc', sem1='$sem1',sem2='$sem2',sem3='$sem3',sem4='$sem4',sem5='$sem5',sem6='$sem6',sem7='$sem7',sem8='$sem8', percentage='$percentage', markentry='1' where studentid ='$id' ";
  if($conn->query($sql) === TRUE){
   echo "<script> alert('Student details UPDATE');
   window.location.href = 'index.php';
   </script>";
  }
  else{
   echo "<script> alert('Student Updation Failed')</script>";  
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>User Home</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">
<style type="text/css">
  #submit{

  }
  #form1{
    padding: 10px;
    margin: 10px;
  }
  #id1{
    display: none;
  }
  #id2{
    display: none;
  }
  #id3{
    display: none;
  }
  #id4{
    display: none;
  }
</style>
</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Welcome to T&P </div>
      <div class="list-group list-group-flush">
        <button type="button" class="btn btn-outline-dark" onclick="myFunction1()">Dashboard</button>
        <button type="button" class="btn btn-outline-dark" onclick="myFunction2()">Events</button>
        <button type="button" class="btn btn-outline-dark" onclick="myFunction3()">Profile</button>
        <button type="button" class="btn btn-outline-dark" onclick="myFunction4()">Status</button>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Student Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Apply Now <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">User Details</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logout.php">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <div id="id1">
          1
        </div>
        <div id="id2">
          2
        </div>
        <div id="id3">
          3
        </div>
        <div id="id4">
          4
        </div>

<form method="post" action="User_Details.php" id="form1">
        <table class="table" >
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Ques</th>
            <th scope="col">Answer</th>
          </tr>
        </thead>
       <!--  <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Current Sem</td>
            <td>
              <select name="CurrentSem">
                <option value="-1" selected>
                  [choose yours]
                </option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
              </select>
            </td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>SSC</td>
            <td><input type="text" name="ssc" maxlength="5" value=" <?php echo $row1[0]; ?>" ></td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>HSC/Diploma</td>
            <td><input type="text" name="hsc" value=" <?php echo $row1[1]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td>Semester 1</td>
            <td><input type="text" id="sem1" name="sem1" required="" value=" <?php echo $row1[2]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">5</th>
            <td>Semester 2</td>
            <td><input type="text" id="sem2" name="sem2" required="" value=" <?php echo $row1[3]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">6</th>
            <td>Semester 3</td>
            <td><input type="text" id="sem3" name="sem3" required="" value=" <?php echo $row1[4]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">7</th>
            <td>Semester 4</td>
            <td><input type="text" id="sem4" name="sem4" required="" value=" <?php echo $row1[5]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">8</th>
            <td>Semester 5</td>
            <td><input type="text" id="sem5" name="sem5" required="" value=" <?php echo $row1[6]; ?>"> </td>
          </tr>
          <tr>
            <th scope="row">9</th>
            <td>Semester 6</td>
            <td><input type="text" id="sem6" name="sem6" required="" value=" <?php echo $row1[7]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">10</th>
            <td>Semester 7</td>
            <td><input type="text" id="sem7" name="sem7" required="" value=" <?php echo $row1[8]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">11</th>
            <td>Semester 8</td>
            <td><input type="text" id="sem8" name="sem8" required="" value=" <?php echo $row1[9]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">12</th>
            <td>Percentage</td>
            <td><input type="text" id="percentage" name="percentage" disabled=""></td>
          </tr>
          <tr>
            <td colspan="3"><button type="button" class="btn btn-dark" onclick="submit1()">Calculte</button> 
              <input type="submit" name="submit" class="btn btn-success" id="myBtn" value="Submit" disabled> 
            </td>
          </tr>
          </tbody> -->
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Current Sem</td>
            <td>
              <select name="CurrentSem">
                <option value="-1" selected>
                  [choose yours]
                </option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
              </select>
            </td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>SSC</td>
            <td><input type="text" name="ssc" maxlength="5" value=" <?php echo $row1[0]; ?>" ></td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>HSC/Diploma</td>
            <td><input type="text" name="hsc" value=" <?php echo $row1[1]; ?>"></td>
          </tr>
          <tr>
            <th scope="row">4</th>
            <td>Semester 1</td>
            <td><input type="text" id="sem1" maxlength="3" name="sem1" required="" value=" <?php echo $row1[2]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">5</th>
            <td>Semester 2</td>
            <td><input type="text" id="sem2" maxlength="3" name="sem2" required="" value=" <?php echo $row1[3]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">6</th>
            <td>Semester 3</td>
            <td><input type="text" id="sem3" maxlength="3" name="sem3" required="" value=" <?php echo $row1[4]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">7</th>
            <td>Semester 4</td>
            <td><input type="text" id="sem4" maxlength="3" name="sem4" required="" value=" <?php echo $row1[5]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">8</th>
            <td>Semester 5</td>
            <td><input type="text" id="sem5" maxlength="3" name="sem5" required="" value=" <?php echo $row1[6]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">9</th>
            <td>Semester 6</td>
            <td><input type="text" id="sem6" maxlength="3" name="sem6" required="" value=" <?php echo $row1[7]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">10</th>
            <td>Semester 7</td>
            <td><input type="text" id="sem7" maxlength="3" name="sem7" required="" value=" <?php echo $row1[8]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">11</th>
            <td>Semester 8</td>
            <td><input type="text" id="sem8" maxlength="3" name="sem8" required="" value=" <?php echo $row1[9]; ?>"><span id='error'></span></td>
          </tr>
          <tr>
            <th scope="row">12</th>
            <td>Percentage</td>
            <td><input type="text" id="percentage" name="percentage" readonly="">

            </td>
          </tr>
          <tr>
            <td colspan="3"><button type="button" class="btn btn-dark" onclick="submit1()">Calculte</button> 
              <input type="submit" name="submit" class="btn btn-success" id="myBtn" value="Submit" disabled> 
            </td>
          </tr>
          </tbody>
        </table>
</form>

      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>


<script type="text/javascript">
  
  function myFunction1() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  if (x.style.display === "none") {
    x.style.display = "block";
  } 
  else{
    x.style.display="none";
    y.style.display = "none";
    z.style.display ="none";
    a.style.display = "none";
  }
}
  
  function myFunction2() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (y.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
    a.style.display="none";
  } else {
    y.style.display = "block";
    x.style.display="none";
    z.style.display = "none";
    a.style.display="none";
  }
}

function myFunction3() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (z.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
  } else {
    z.style.display = "block";
    x.style.display="none";
    y.style.display = "none";
  }
}

function myFunction4() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (a.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
    a.style.display = "none";
  } else {
    a.style.display = "block";
    x.style.display="none";
    z.style.display = "none";
    y.style.display="none";
  }
}

</script>




<script type="text/javascript">

 function submit1() {
    document.getElementById("myBtn").disabled = false;



     var sem1 = document.getElementById("sem1").value;
     var sem2 = document.getElementById("sem2").value;
     var sem3 = document.getElementById("sem3").value;
     var sem4 = document.getElementById("sem4").value;
     var sem5 = document.getElementById("sem5").value;
     var sem6 = document.getElementById("sem6").value;
     var sem7 = document.getElementById("sem7").value;
     var sem8 = document.getElementById("sem8").value;
    
     var num1 = parseInt(sem1)
     var num2 = parseInt(sem2)
     var num3 = parseInt(sem3)
     var num4 = parseInt(sem4)
     var num5 = parseInt(sem5)
     var num6 = parseInt(sem6)
     var num7 = parseInt(sem7)
     var num8 = parseInt(sem8)
     
    var cursemelement = document.getElementsByName('CurrentSem')[0]
     var cursem = cursemelement.options[cursemelement.selectedIndex].value
     var num = parseInt(cursem)

    // document.write("Sum Sem1 : "+sem1)
    // document.write("<br>Sum Sem2 : "+sem2)
    // document.write("<br>Sum Sem3 : "+sem3)
    // document.write("<br>Sum Sem4 : "+sem4)
    // document.write("<br>Sum Se5 : "+sem5)
    // document.write("<br>Sum Sem6 : "+sem6)
    // document.write("<br>Sum Sem7 : "+sem7)
    // document.write("<br>Sum Sem8 : "+sem8)
    // document.write("<br>cur Sem : "+cursem)

     var sumsem = parseFloat(num1 + num2 + num3+ num4+ num5+ num6+ num7+ num8);
    // document.write("<br>Sum Sem : "+sumsem)
     var avgsumsem = parseFloat(sumsem/num);
    // document.write("<br>Avg Sem : "+avgsumsem)
     var percent = parseFloat(7.1 * avgsumsem + 12) ;
    alert("Percentage ="+percent)
    
    document.getElementById("percentage").value = percent;
  }

  var cursemelement = document.getElementsByName('CurrentSem')[0]

  cursemelement.onblur = function () {
    // body...
    var cursem = cursemelement.options[cursemelement.selectedIndex].value ;//document.CurrentSem.value;


    if (cursem==6) {
      document.getElementById("sem7").disabled = true;
      document.getElementById("sem8").disabled = true;
      document.getElementById("sem7").value = 0
      document.getElementById("sem8").value = 0
    } else if (cursem==7) {
      document.getElementById("sem7").disabled = false;
      document.getElementById("sem8").disabled = true;
      document.getElementById("sem8").value = 0
    }
    else if(cursem ==8)
    {
      document.getElementById("sem7").disabled = false;
      document.getElementById("sem8").disabled = false;
      document.getElementById("sem8").value = "";
      document.getElementById("sem7").value = ""; 
    }
  }
</script>
</body>

</html>


