
<?php 
include 'conn.php';
if (isset($_POST['submit'])) {
	$jobid = $_POST['jobid'];
	$id = $_POST['id'];
	
	$sql3 = "SELECT hrid from job where jobid = '$jobid' ";
	if($res = $conn->query($sql3)){
		$rowres = mysqli_fetch_array($res);
		$hrid = $rowres[0];
		// echo $hrid,"<br>";
		// echo $jobid,"<br>";
		// echo $id,"<br>";
		$sqlinsert = "INSERT into user_job_reg (hrid,jobid,studentid) VALUES ('$hrid', '$jobid', '$id')";
		if ($conn->query($sqlinsert)===TRUE) {
			echo "
			<script>
			alert('Successfully Registered for JOB');
			window.location.href = 'index.php';
			 </script>
			";
		    // echo "New record created successfully";
		} else 
		{
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}	
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>