<?php 

session_start();

echo $_SESSION['email'],"<br>";
echo $_SESSION['fullname'],"<br>";
echo $_SESSION['id'],"<br>";


?>