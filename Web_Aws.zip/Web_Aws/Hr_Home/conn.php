<?php  
$servername = "test.c6rk6zvod6ql.us-east-2.rds.amazonaws.com";
$username = "admin123";
$password = "admin123";
$dbname = "aws";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



?>