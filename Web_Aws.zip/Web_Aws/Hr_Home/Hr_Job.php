<?php
session_start();

include 'conn.php';

$hrid = $_SESSION['hrid'];

if (isset($_POST['submit'])  ) {
  # code...
  $ctc = $_POST['ctc'];
  $stream = $_POST['stream'];
  #$stream1 = " ";
  if($stream == 1)
    $stream1="COMPS";
  else if ($stream1 == 2)
    $stream1="IT";
  else 
    $stream1="COMP/IT";
  
  $location = $_POST['location'];
  $profile = $_POST['profile'];
  $ssc = $_POST['ssc'];
  $hsc = $_POST['hsc'];
  $be = $_POST['be'];
  $round = $_POST['rounds'];
  $date = $_POST['date'];

  // echo  $ctc,"<br>";
  // echo  $stream,"<br>";
  // echo  $location,"<br>";
  // echo  $profile,"<br>";
  // echo  $ssc,"<br>";
  // echo  $hsc,"<br>";
  // echo  $be,"<br>";
  // echo  sizeof ($round),"<br>";
  // echo  $date,"<br>";

  $sql = " INSERT INTO `job`(`hrid`, `ctc`, `stream`, `location`, `designation`, `ssc`, `hsc`, `be_criteria`, `date`, `round`) 
            VALUES ('$hrid', '$ctc','$stream1','$location','$profile','$ssc','$hsc','$be','$date','$round')";
  // mysqli_query($conn,$sql);
  if($conn->query($sql) === TRUE){
   echo "<script> alert('Job Added Successfully')</script>";
   header("location:index.php");
#   $last_id = $conn->insert_id;
  }
  else{
   echo "<script> alert('Failed to add contact admin')</script>"; 
  }

}

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>HR Home</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">
<style type="text/css">
  #id1{
    display: block;
  }
  #id2{
    display: none;
  }
  #id3{
    display: none;
  }
  #id4{
    display: none;
  }
</style>
</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <!-- <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>
 -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Apply Now <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#" onclick="check();">Add Job</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <div id="id1">
          <h3>HR job</h3>
          <center>
            <form method="post" action="Hr_Job.php">
          <table class="table table-primary table-hover table-stripped table-fixed" style="width: 40%;">
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Ques</th>
            <th scope="col">Answer</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
          <th>Offering CTC (Lakhs) </th>
          <td><input type="text" name="ctc" id="fn1" maxlength="10" title="How much you can offer" placeholder="How much you can offer" required/></td>
          </tr>
          

          <tr>
          <th scope="row">2</th>  
          <th>For Which Stream</th>
          <td>
            <select name="stream">
            <option value="" selected="selected" disabled="disabled">Select Stream</option>
            <option value="1">CS</option>
            <option value="2">IT</option>
            <option value="3">CS/IT</option>
            </select>
          </td>
          </tr>


          <tr>
          <th scope="row">3</th>
          <th>Job Location</th>
          <td><input type="text"/ name="location"></td>
          </tr>
          <tr>
          <th scope="row">4</th>
          <th>Job Profile</th>
          <td><input type="text"/ name="profile"></td>
          </tr>
          <tr>
          <th scope="row">5</th>
          <th>SSC  Criteria</th>
          <td><input type="text"/ name="ssc"></td>
          </tr>

          <tr>
          <th scope="row">5</th>
          <th>HSC/Diploma Criteria</th>
          <td><input type="text"/ name="hsc"></td>
          </tr>


          <tr>
          <th scope="row">6</th>
          <th>BE Criteria </th>
          <td><input type="text"/ name="be"></td>
          </tr>
          
          <tr>
          <th scope="row">7</th>
          <th>No of Rounds to be conducted</th>
          <td>
            <select name="rounds">
            <option value="" selected="selected" disabled="disabled">No of Rounds</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>

            </select>
          </td>
          </tr>
          
          <tr>
          <th scope="row">8</th>
          <th>Date of Conducting</th>
          <td><input type="date"/ name="date"></td>
          </tr>

          <tr>
          <td colspan="3" align="center">
          <input type="submit" value="Save My Data" name="submit">
          <input type="reset" value="Reset Data">
          </td>
          </tr>
        </tbody>
          </table>
        </form>
          </center>
        </div>
      </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>


<script type="text/javascript">
  
  function myFunction1() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  if (x.style.display === "none") {
    x.style.display = "block";
  } 
  else{
    x.style.display="none";
    y.style.display = "none";
    z.style.display ="none";
    a.style.display = "none";
  }
}
  
  function myFunction2() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (y.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
    a.style.display="none";
  } else {
    y.style.display = "block";
    x.style.display="none";
    z.style.display = "none";
    a.style.display="none";
  }
}

function myFunction4() {
  var x = document.getElementById("id1");
  var y = document.getElementById("id2");
  var z = document.getElementById("id3");
  var a = document.getElementById("id4");
  // if (x.style.display ==="block") {
  //   x.style.display="block";
  // }
  if (a.style.display === "block") {
    y.style.display = "none";
    x.style.display = "none";
    z.style.display ="none";
    a.style.display = "none";
  } else {
    a.style.display = "block";
    x.style.display="none";
    z.style.display = "none";
    y.style.display="none";
  }
}


function check(){
  var name = <?php echo json_encode($status); ?>;
  if(name === '0'){
    alert("Wait for TPO approval");
  }
  else{
    alert("TPO approved for registering Job");
    window.location.href = 'Hr_Job.php';
  }
}

</script>
</body>

</html>