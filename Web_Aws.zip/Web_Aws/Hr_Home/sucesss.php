<?php


include 'conn.php';
session_start();
$jobid = $_SESSION['jobid'];
                        if (isset($_GET['Select'])) {
                                $studid = $_GET['Select'];
                                echo "<script>
                                alert('Select');
                                </script>";
                                $sql = "UPDATE user_job_reg SET status = 'Select' where studentid = '$studid' and jobid='$jobid' ";
                                mysqli_query($conn,$sql);
                                $sql1 = " UPDATE student_info SET placed= '1' WHERE studentid = '$studid' ";
                                mysqli_query($conn,$sql1);
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);       
                        }

                        if (isset($_GET['Reject'])) {
                                $studid = $_GET['Reject'];
                                echo "<script>
                                alert('Reject');
                                </script>";
                                $sql = "UPDATE user_job_reg SET status = 'Reject' where studentid = '$studid' and jobid='$jobid' ";
                                mysqli_query($conn,$sql);
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);       
                        }

                        if (isset($_GET['Fail'])) {
                                $studid = $_GET['Fail'];
                                echo "<script>
                                alert('Fail');
                                </script>";
                                $sql = "UPDATE user_job_reg SET status = 'Fail' where studentid = '$studid' and jobid='$jobid' ";
                                mysqli_query($conn,$sql);
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);       
                        }
// $jobid = 1;
        		if (isset($_POST['submit'])) {
        			$noofchecbox = count($_POST['r']);
        			$stage = $_POST['new'];
        			// $url = "viewstudent.php?jobid=$undecode";
        			$i = 0 ;
        			while ($i < $noofchecbox) {
        				$key = $_POST['r'][$i];
        				$sql = " UPDATE user_job_reg SET round='$stage' WHERE studentid = '$key' and jobid = '$jobid' ";
        				mysqli_query($conn,$sql);
                                        $i++;
        			}
        			// header('Location:index.php');
                                echo "<script>
                                alert('Updated');
                                </script>";
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);
        		}




?>