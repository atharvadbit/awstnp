<?php
session_start();
include 'conn.php';
$hrid = $_SESSION['hrid'];

$flag = 0;
if (isset($_GET['jobid'])) {
	$undecode = $_GET['jobid'];
	$_SESSION['jobid'] =  base64_decode($_GET['jobid']);
	// $jobid = $_SESSION['jobid'];
	
}
$jobid = $_SESSION['jobid'];
#$sql = " SELECT * from jobs where jobid = '$jobid' "










 if (isset($_GET['Select'])) {
                                $studid = $_GET['Select'];
                                echo "<script>
                                alert('Select');
                                </script>";
                                $sql = "UPDATE user_job_reg SET status = 'Select' where studentid = '$studid' and jobid='$jobid' ";
                                mysqli_query($conn,$sql);
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);       
                        }

                        if (isset($_GET['Reject'])) {
                                $studid = $_GET['Reject'];
                                echo "<script>
                                alert('Reject');
                                </script>";
                                $sql = "UPDATE user_job_reg SET status = 'Reject' where studentid = '$studid' and jobid='$jobid' ";
                                mysqli_query($conn,$sql);
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);       
                        }

                        if (isset($_GET['Fail'])) {
                                $studid = $_GET['Fail'];
                                echo "<script>
                                alert('Fail');
                                </script>";
                                $sql = "UPDATE user_job_reg SET status = 'Fail' where studentid = '$studid' and jobid='$jobid' ";
                                mysqli_query($conn,$sql);
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);       
                        }
// $jobid = 1;
        		if (isset($_POST['submit'])) {
        			$noofchecbox = count($_POST['r']);
        			$stage = $_POST['new'];
        			// $url = "viewstudent.php?jobid=$undecode";
        			$i = 0 ;
        			while ($i < $noofchecbox) {
        				$key = $_POST['r'][$i];
        				$sql = " UPDATE user_job_reg SET round='$stage' WHERE studentid = '$key' and jobid = '$jobid' ";
        				mysqli_query($conn,$sql);
                                        $i++;
        			}
        			// header('Location:index.php');
                                echo "<script>
                                alert('Updated');
                                </script>";
                                $id = base64_encode($jobid);
                                $url = "viewstudent.php?jobid=$id";
                                header("Location: ".$url);
        		}




























?>

<!DOCTYPE html>
<html>
<head>



  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <title>Student Register</title>

  <!-- Bootstrap core CSS -->
 <!--  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  Custom styles for this template
  <link href="css/simple-sidebar.css" rel="stylesheet">
 -->
</head>
<body>

<div class="container-fluid">
        <div id="id1">
        	<h3>Students Details</h3>
            <a href="index.php" class="button-primary"> Home Page</a>
        	<form method="post" action="viewstudent.php">
        		
        	<table class="table table-hover table-stripped table-fixed" style="width: 100%;">
        		<thead>
        			<tr align="center">
        				<th colspan="3">Job ID : <?php echo $_SESSION['jobid']; ?></th>
        				<th colspan="3">Job Desgination</th>
        				<th>Rounds 
        						<select name="new">
                                    <option value="1">1</option>
        							<option value="2">2</option>
        							<option value="3">3</option>
        						</select>
        				</th>
        				<th>Status
        					<select name="status">
        							<option value="NULL">Null</option>
        							<option value="Select">Select</option>
        							<option value="Reject">Reject</option>
        							<option value="Fail">Fail</option>
        						</select>
        						<input type="submit" name="view" value="View" class="btn btn-info">
        				</th>
        			</tr>	
        			<tr>
        				<th>Student ID</th>
        				<th>Student Name</th>
        				<th>Branch</th>
        				<th>College</th>
        				<th>Current Sem</th>
        				<th>SSC</th>
        				<th>HSC / Diploma</th>
        				<th>BE</th>
        				<th>Rounds</th>
        				<th>Status</th>
        				<th>Action</th>
        			</tr>
        		</thead>
        				<?php
        				
        				$veiwsql= " SELECT s.studentid, s.fullname,	s.branch, s.clg, s.currentsem, s.ssc, s.hsc_diploma, s.percentage, u.round,u.status 		from student_info s INNER JOIN user_job_reg u on s.studentid = u.studentid where u.jobid= '$jobid' ";
                     
            				if ($result = $conn->query($veiwsql)) {
                  		// output data of each row
        				$count = mysqli_num_rows($result);
        				#$c = 0;
                  		while($rowjob = mysqli_fetch_array($result)) { ?>
        				<tr>
        					<script type="text/javascript">
        						var c=0;
        					</script>
        					  <td> <?php echo $rowjob[0]  ?>   </td>
        					  <td> <?php echo $rowjob[1]  ?>   </td>		
        					  <td> <?php echo $rowjob[2]  ?>   </td>
        					  <td> <?php echo $rowjob[3]  ?>   </td>
        					  <td> <?php echo $rowjob[4]  ?>   </td>		
        					  <td> <?php echo $rowjob[5]  ?>   </td>
							  <td> <?php echo $rowjob[6]  ?>   </td>
        					  <td> <?php echo $rowjob[7]  ?>   </td>		
        					  <td> <?php echo $rowjob[8]  ?>  
								<input type="checkbox" name="r[]" value=" <?php echo $rowjob[0] ?> "> 
        					  	<!-- <input type="hidden" name="r[  <script> document.write(c); </script>  ]" value="0"> 
	<input type="hidden" name="studid[]" value=" <?php echo $rowjob[0] ?> "> 
        					  	-->
        					  </td>   
        					  <td> <?php echo $rowjob[9];
     					  			?>
        					  </td>        				
        					  <td>

        						<!-- <a href="#" class="button button-primary">Pass</a> -->
        						<a href="viewstudent.php?Select=<?php echo $rowjob[0]; ?>" class="btn btn-success" role="button">Select</a>
        						<a href="viewstudent.php?Reject=<?php echo $rowjob[0]; ?>" class="btn btn-warning" role="button">Reject</a>
        						<a href="viewstudent.php?Fail=<?php echo $rowjob[0]; ?>" class="btn btn-danger" role="button">Fail</a>
        						</td>
        				</tr>
        			 <?php }
              } else {
                  echo "<script> alert('Error 1') </script>";
              }


            ?>

        	</table>
        	<input type="submit" class="btn btn-info" name="submit">
        	</form>

        	


        	

        </div>
</div>

<script type="text/javascript">

		
</script>
</body>
</html>