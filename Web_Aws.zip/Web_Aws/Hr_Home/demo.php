<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
if (isset($_POST['submit'])) {
	# code...
	$sid = $_POST['id'];
	$url = "edit.php?sid=$sid";
	header("Location: ".$url);
}

?>
<form method="post" action="demo.php">
	<input type="number" name="id">
	<input type="submit" name="submit">
</form>


</body>
</html>