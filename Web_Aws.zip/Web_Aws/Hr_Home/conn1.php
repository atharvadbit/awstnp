<?php  

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
mysql_connect($servername, $username, $password, $dbname);
mysql_select_db($dbname);



?>