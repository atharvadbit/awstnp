<?php

include 'conn.php';

if (isset($_GET['updateyes'])) {
  $hrid=$_GET['updateyes'];

  $sql1 = "UPDATE hr_job set status=1 where hrid='$hrid'";
  if($conn->query($sql1) === TRUE){
   echo "<script> alert('HR details Approved');
   window.location.href = 'hrdetails.php';
   </script>";
  }
  else{
   echo "<script> alert('Approved Failed')</script>";  
  }

}
if (isset($_GET['updateno'])) {
  $hrid=$_GET['updateno'];

  $sql1 = "UPDATE hr_job set status=0 where hrid='$hrid'";
  if($conn->query($sql1) === TRUE){
   echo "<script> alert('HR Details Reject');
   window.location.href = 'hrdetails.php';
   </script>";
  }
  else{
   echo "<script> alert('Approved Failed')</script>";  
  }

}

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>HR Details</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style type="text/css">
  #id1{
    display: block;
  }
  #id2{
    display: none;
  }
  #id3{
    display: none;
  }
  #id4{
    display: none;
  }
</style>
</head>

<body>

  <div class="d-flex" id="wrapper">


    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">HR Details</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Students
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="studentdetails.php">View Students</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="placed.php">Student Placed</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Recruiter
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="hrdetails.php">View HR</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="drivedetails.php">Drive Details</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>



            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logout.php">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="index.php">Home</a>
              </div>
            </li>

          </ul>
        </div>
        
      </nav>


      <div class="container-fluid">
        <div align="center">
          <br>
          <br>
        <h2>HR Recruiter Details</h2>
        <hr>
        <table class="table table-light table-striped table-hover table-fixed" style="width: 75%;">
            <thead class="thead-dark">
            <tr>
            <th>HR ID </th>
            <th>HR Name</th>
            <th>HR Email</th>
            <th>HR Company</th>
            <th>Address</th>
            <th>Status</th>
            <th>View Drives to Conducted</th>
          </tr>
          </thead>
              <?php  
                $sql = "SELECT hrid,hrname,hremail,hrcompany,address,status from hr_job";
                if ($result = $conn->query($sql)) {
                  // output data of each row
                  while($rowjob = $result->fetch_assoc()) { ?>        
                   <tr>
                          <td><?php echo $rowjob['hrid'] ?>  </td>
                          <td><?php echo $rowjob['hrname'] ?> </td>
                          <td><?php echo $rowjob['hremail'] ?></td>
                          <td><?php echo $rowjob['hrcompany'] ?></td>
                          <td><?php echo $rowjob['address'] ?></td>
                          <td><?php echo $rowjob['status'] ?> <a href="hrdetails.php?updateyes= <?php echo $rowjob['hrid']  ?>">Yes</a> &nbsp <a href="hrdetails.php?updateno= <?php echo $rowjob['hrid']  ?>">No</a> </td>
                          <td> <a href="hrdrivedetails.php?hrid= <?php echo  $rowjob['hrid'];?>" target="_blank"> View Details</a></td>
                       </tr> 
                 <?php }
              } 
            ?>
        </table>





        </div>
      </div>

    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<footer class="container-fluid text-center fixed-bottom">
  <p>Footer Text</p>
</footer>



</body>

</html>
