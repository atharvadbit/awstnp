<?php
include 'conn.php';
$sql = " SELECT  s.studentid, s.fullname, s.branch, s.clg,  h.hrname, h.hrcompany, u.jobid, j.ctc, j.stream, j.location, j.designation, j.date, u.round, u.status from hr_job h inner join user_job_reg u on h.hrid = u.hrid inner JOIN job j on j.jobid = u.jobid inner join student_info s on u.studentid = s.studentid   where  u.status like 'Select'  ";
  $Result = mysqli_query($conn, $sql);


?>


<!DOCTYPE html>
<html lang="en">

<head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>Placed Details</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style type="text/css">
  #id1{
    display: block;
  }
  #id2{
    display: none;
  }
  #id3{
    display: none;
  }
  #id4{
    display: none;
  }
</style>
</head>

<body>

  <div class="d-flex" id="wrapper">


    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Placed Details</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

       <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Students
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="studentdetails.php">View Students</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="placed.php">Student Placed</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Recruiter
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="hrdetails.php">View HR</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="drivedetails.php">Drive Details</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>



            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logout.php">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="index.php">Home</a>
              </div>
            </li>

          </ul>
        </div>
        
      </nav>
      <div class="container-fluid">
        <div align="center">
          <br>
          <h3>Placed Student List</h3>
<hr>
        <table class="table table-light table-striped table-hover table-fixed" style="width: 85%;">
            <thead class="thead-dark">
              <tr>
                <th>Student ID</th>
                <th>Full Name</th>
                <th>Branch</th>
                <th>Clg</th>
                <th>Name</th>

                <th>Hr Company</th>
                <th>Job ID</th>
                <th>CTC</th>
                <th>Stream</th>
                <th>Location</th>
                <th>Designation</th>
                <th>Date</th>
                <th>Round</th>
                <th>Status</th>
              </tr>
            </thead>


           <?php while($row = mysqli_fetch_array($Result)):?>
            <tr>
                <td> <?php  echo $row['studentid']; ?></td>
                <td> <?php  echo $row['fullname']; ?></td>
                <td> <?php  echo $row['branch']; ?></td>
                <td> <?php  echo $row['clg']; ?></td>
                <td> <?php  echo $row['hrname']; ?></td>

                <td> <?php  echo $row['hrcompany']; ?></td>
                <td> <?php  echo $row['jobid']; ?></td>
                <td> <?php  echo $row['ctc']; ?></td>
                <td> <?php  echo $row['stream']; ?></td>
                <td> <?php  echo $row['location']; ?></td>
                <td> <?php  echo $row['designation']; ?></td>
                <td> <?php  echo $row['date']; ?></td>
                <td> <?php  echo $row['round']; ?></td>
                <td> <?php  echo $row['status']; ?></td>
            </tr>
          <?php endwhile;?>
          </table>

<hr>





        </div>
      </div>

    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<footer class="container-fluid text-center fixed-bottom">
  <p>Footer Text</p>
</footer>



</body>

</html>
