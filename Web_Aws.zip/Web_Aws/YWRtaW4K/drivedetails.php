<?php

include 'conn.php';

// $sql = " SELECT  h.hrcompany,h.hrname,h.hremail, j.jobid, j.ctc, j.stream, j.designation, j.date from  hr_job h inner join job j on h.hrid = j.hrid  where j.status=0 ";
// $Result = mysqli_query($conn, $sql);

if (isset($_POST['view'])) {
$s = "Drive Approved";
$sql = " SELECT  h.hrcompany,h.hrname,h.hremail, j.jobid, j.ctc, j.stream, j.designation, j.date from  hr_job h inner join job j on h.hrid = j.hrid  where j.status=1 ";
$Result = mysqli_query($conn, $sql);

}
else
{
$s = "Drive to Pending";
$sql = " SELECT  h.hrcompany,h.hrname,h.hremail, j.jobid, j.ctc, j.stream, j.designation, j.date from  hr_job h inner join job j on h.hrid = j.hrid  where j.status=0 ";
$Result = mysqli_query($conn, $sql);  
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  <title>All Drive Details</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/simple-sidebar.css" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<style type="text/css">
  #id1{
    display: block;
  }
  #id2{
    display: none;
  }
  #id3{
    display: none;
  }
  #id4{
    display: none;
  }
</style>
</head>

<body>

  <div class="d-flex" id="wrapper">


    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">All Drive Details</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Students
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="studentdetails.php">View Students</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="placed.php">Student Placed</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Recruiter
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="hrdetails.php">View HR</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="drivedetails.php">Drive Details</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Help</a>
              </div>
            </li>



            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Options
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="logout.php">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="index.php">Home</a>
              </div>
            </li>

          </ul>
        </div>
        
      </nav>


      <div class="container-fluid">
        <div>
          <center>
            <br>
          <form action="drivedetails.php" method="POST">
            <input type="radio" name="view"> Drive Approved
            <input type="radio" name=""> Drive to Pending
            <input type="submit" name="submit">
          </form>
          <br>
          <h3> <?php  echo $s; ?></h3>  
         <hr>
         <table class="table table-light table-striped table-hover table-fixed" style="width: 75%;">
             <thead class="thead-dark">
              <tr>
                <th>Job ID</th>
                <th>HR Name</th>
                <th>HR Company</th>
                <th>HR Email</th>
                <th>Designation</th>
                <th>CTC</th>
                <th>Sream</th>
                <th>Date</th>
                <th>View</th>
              </tr>




            </thead>
          
             <?php while($row = mysqli_fetch_array($Result)):?>

              <tr>
                <td> <?php  echo $row['jobid']; ?></td>
                <td> <?php  echo $row['hrname']; ?></td>
                <td> <?php  echo $row['hrcompany']; ?></td>
                <td> <?php  echo $row['hremail']; ?></td>
                <td> <?php  echo $row['designation']; ?></td>
                <td> <?php  echo $row['ctc']; ?></td>
                <td> <?php  echo $row['stream']; ?></td>
                <td> <?php  echo $row['date']; ?></td>    
                <td> <a href="onedd.php?jobid=<?php echo $row['jobid'];  ?> ">View Students </a>  </td>


              </tr>

            <?php endwhile;?>

          </table>          
          </center>
<hr>





        </div>
      </div>

    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<footer class="container-fluid text-center fixed-bottom">
  <p>Footer Text</p>
</footer>



</body>

</html>
